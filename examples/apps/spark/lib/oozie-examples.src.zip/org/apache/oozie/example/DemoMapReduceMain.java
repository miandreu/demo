package org.apache.oozie.example;

import org.apache.oozie.action.hadoop.MapReduceMain;

public class DemoMapReduceMain extends MapReduceMain
{
}

/* Location:           C:\Users\Miquel Angel Andreu\Downloads\demo\demo\examples\apps\spark\lib\oozie-examples.jar
 * Qualified Name:     org.apache.oozie.example.DemoMapReduceMain
 * JD-Core Version:    0.6.2
 */