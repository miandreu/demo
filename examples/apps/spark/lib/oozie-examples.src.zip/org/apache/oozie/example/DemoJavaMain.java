/*    */ package org.apache.oozie.example;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class DemoJavaMain
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 23 */     System.out.println("Demo Java Main");
/*    */ 
/* 25 */     System.out.println("# Arguments: " + args.length);
/* 26 */     for (int i = 0; i < args.length; i++)
/* 27 */       System.out.println("Argument[" + i + "]: " + args[i]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Miquel Angel Andreu\Downloads\demo\demo\examples\apps\spark\lib\oozie-examples.jar
 * Qualified Name:     org.apache.oozie.example.DemoJavaMain
 * JD-Core Version:    0.6.2
 */