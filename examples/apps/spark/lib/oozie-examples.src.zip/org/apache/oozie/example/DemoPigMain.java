package org.apache.oozie.example;

import org.apache.oozie.action.hadoop.PigMain;

public class DemoPigMain extends PigMain
{
}

/* Location:           C:\Users\Miquel Angel Andreu\Downloads\demo\demo\examples\apps\spark\lib\oozie-examples.jar
 * Qualified Name:     org.apache.oozie.example.DemoPigMain
 * JD-Core Version:    0.6.2
 */